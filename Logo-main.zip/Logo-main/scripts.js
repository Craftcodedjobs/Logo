$(document).ready(function(){
    $(".burgermenu").on("click", function(){
        $(".mob-nav").fadeToggle();
    })
})